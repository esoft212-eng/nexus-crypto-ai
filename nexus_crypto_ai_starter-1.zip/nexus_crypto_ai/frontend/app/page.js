'use client';
import { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
const naira = v => Number.isFinite(Number(v)) ? '₦' + Number(v).toLocaleString('en-NG',{maximumFractionDigits:2}) : '—';

export default function Home() {
  const [config,setConfig]=useState(null),[portfolio,setPortfolio]=useState(null),[teams,setTeams]=useState([]),[ledger,setLedger]=useState([]),[events,setEvents]=useState([]),[error,setError]=useState('');
  async function refresh(){
    try {
      const urls=['/v1/config','/v1/portfolio','/v1/teams','/v1/ledger','/v1/events'];
      const responses=await Promise.all(urls.map(u=>fetch(API+u,{cache:'no-store'})));
      if(!responses.every(r=>r.ok)) throw new Error('API returned an error');
      const data=await Promise.all(responses.map(r=>r.json()));
      setConfig(data[0]);setPortfolio(data[1]);setTeams(data[2]);setLedger(data[3]);setEvents(data[4]);setError('');
    } catch(e){setError(`${e.message}. Start with docker compose up --build.`);}
  }
  useEffect(()=>{refresh();const id=setInterval(refresh,5000);return()=>clearInterval(id)},[]);
  const pnl=Number(portfolio?.net_pnl||0),equity=Number(portfolio?.equity||config?.starting_capital_ngn||100000);
  return <main>
    <div className="header"><div><div className="eyebrow">Paper trading command center</div><h1>NEXUS CRYPTO AI</h1><div className="sub">100 configured agents · 10 independent teams · BTC / ETH · 1h</div></div><div className="pill">● PAPER MODE · LIVE ORDERS DISABLED</div></div>
    {error&&<div className="errorbox">{error}</div>}
    <div className="grid">
      <div className="card"><div className="label">Virtual equity</div><div className="value">{naira(equity)}</div><div className="muted">Starting capital {naira(config?.starting_capital_ngn||100000)}</div></div>
      <div className="card"><div className="label">Net P&amp;L</div><div className={'value '+(pnl>=0?'status':'error')}>{pnl>=0?'+':''}{naira(pnl)}</div><div className="muted">Paper results only</div></div>
      <div className="card"><div className="label">Strategy teams</div><div className="value">{teams.length||10} / 10</div><div className="muted">{config?.agent_count||100} configured agents</div></div>
      <div className="card"><div className="label">Daily target</div><div className="value">20%</div><div className="muted">Aspirational, not guaranteed</div></div>
    </div>
    <section className="section"><div className="section-head"><h2>Team performance</h2><span className="muted">Refreshes every 5 seconds</span></div>
      <div className="card tablewrap"><table><thead><tr><th>Team</th><th>Strategy</th><th>Equity</th><th>Net P&amp;L</th><th>Open positions</th><th>Risk state</th></tr></thead>
      <tbody>{teams.map(t=>{const p=Number(t.equity)-Number(t.starting_equity);return <tr key={t.team_id}><td><strong>{t.team_id}</strong><div className="muted">{t.name}</div></td><td>{t.strategy}</td><td>{naira(t.equity)}</td><td className={p>=0?'status':'error'}>{p>=0?'+':''}{naira(p)}</td><td>{t.positions}</td><td className={t.paused?'error':'status'}>{t.paused?'PAUSED':'READY'}</td></tr>})}</tbody></table></div>
    </section>
    <section className="section"><div className="section-head"><h2>Carry-forward target ledger</h2><span className="muted">Accounting only</span></div>
      <div className="card tablewrap"><table><thead><tr><th>Team</th><th>Target</th><th>Outstanding shortfall</th><th>Completed periods</th></tr></thead>
      <tbody>{ledger.map(l=><tr key={l.team_id}><td>{l.team_id}</td><td>{(Number(l.target_rate)*100).toFixed(0)}%</td><td>{naira(l.outstanding_shortfall)}</td><td>{l.completed_periods}</td></tr>)}</tbody></table>
      <div className="note">Shortfalls never force trades, increase risk, or keep losing positions open.</div></div>
    </section>
    <section className="section"><div className="section-head"><h2>System events</h2><span className="muted">Latest {events.length}</span></div>
      <div className="card tablewrap">{events.length===0?<div className="muted">No events yet. Submit candles through the API to begin paper evaluation.</div>:
      <table><thead><tr><th>Time</th><th>Level</th><th>Team</th><th>Message</th></tr></thead><tbody>{[...events].reverse().map((e,i)=><tr key={i}><td>{new Date(e.timestamp).toLocaleString()}</td><td>{e.level}</td><td>{e.team_id||'—'}</td><td>{e.message}</td></tr>)}</tbody></table>}</div>
    </section>
    <div className="note">Starter build · Paper simulation only · No live order placement. Results depend on supplied candle data and simulation assumptions. No return is guaranteed.</div>
  </main>;
}

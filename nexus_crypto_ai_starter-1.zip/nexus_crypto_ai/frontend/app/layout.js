import './globals.css';
export const metadata = { title: 'NEXUS Crypto AI', description: 'Paper trading command center' };
export default function RootLayout({ children }) { return <html lang="en"><body>{children}</body></html>; }

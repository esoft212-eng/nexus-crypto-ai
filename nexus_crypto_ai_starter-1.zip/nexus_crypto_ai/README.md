# NEXUS Crypto AI — Paper Trading Starter

Paper-trading starter only. No live order placement or guaranteed returns.

## Configuration
- NGN 100,000 virtual starting equity; 10 teams × NGN 10,000
- 100 configured agent roles (10 per team)
- BTC/USDT and ETH/USDT, 1-hour candles
- Assumed fee 0.1% per executed side
- Planned risk per trade 0.5% of current team equity
- Daily loss pause threshold 2% of team start-of-day equity
- Aspirational daily target 20%; target shortfall is ledger-only
- Equity-based position sizing enabled

## Run with Docker
Prerequisite: Docker + Docker Compose.
```bash
docker compose up --build
```
Dashboard: http://localhost:3000  
API docs: http://localhost:8000/docs  
Health: http://localhost:8000/health

## Run backend locally
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Tests: `cd backend && pytest -q`

## API flow
Submit chronological hourly candles to `POST /v1/market/candles`, then run `POST /v1/engine/evaluate` with `{"symbol":"BTC/USDT"}`. Inspect `/v1/portfolio`, `/v1/teams`, `/v1/agents`, `/v1/positions`, `/v1/ledger`, `/v1/events`.

Example candle submission:
```bash
curl -X POST http://localhost:8000/v1/market/candles \
 -H 'Content-Type: application/json' \
 -d '{"symbol":"BTC/USDT","timeframe":"1h","candles":[{"timestamp":"2026-01-01T00:00:00Z","open":90000,"high":90500,"low":89500,"close":90200,"volume":100}]}'
```
Submit at least 25–30 sequential candles to make sample strategies useful. Prices in examples are illustrative.

## Architecture
- FastAPI API, deterministic strategy interfaces, paper execution engine
- PostgreSQL schema under `backend/sql/schema.sql`
- Next.js dashboard under `frontend/`
- 100 agent configurations generated from 10 strategy-role templates

## Honest limitations
The starter's runtime state is in-memory; it resets on API restart. PostgreSQL is provisioned and schema included, but transactional repository persistence is a clearly identified next step, not falsely represented as complete. The candle interface accepts submitted data; no live market feed is enabled. Some strategy families use baseline strategies until their own rule modules are implemented. The executor uses a deterministic candle-based model, not an exchange order book. Backtest and forward-test before relying on results.

The 20% daily target is aspirational. A shortfall never triggers forced trades, leverage, increased risk, or keeping losing positions open. The daily pause is a risk control, not a guarantee against larger losses.

Before production: add authentication/authorization, database-backed state and transactions, market-feed validation, idempotent order execution, realistic spreads/partial fills, operational monitoring, recovery tests, walk-forward backtests, and security review. No exchange credentials are collected and no live-order endpoint exists.

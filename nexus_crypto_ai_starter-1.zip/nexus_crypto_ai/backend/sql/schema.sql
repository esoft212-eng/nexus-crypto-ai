CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS teams (
 team_id TEXT PRIMARY KEY, name TEXT NOT NULL, strategy_key TEXT NOT NULL,
 starting_equity NUMERIC(24,8) NOT NULL CHECK(starting_equity >= 0), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS agents (
 agent_id TEXT PRIMARY KEY, team_id TEXT NOT NULL REFERENCES teams(team_id), role TEXT NOT NULL,
 strategy_key TEXT NOT NULL, enabled BOOLEAN NOT NULL DEFAULT TRUE, config JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS candles (
 symbol TEXT NOT NULL, timeframe TEXT NOT NULL, candle_time TIMESTAMPTZ NOT NULL,
 open NUMERIC(24,8) NOT NULL CHECK(open>0), high NUMERIC(24,8) NOT NULL CHECK(high>0),
 low NUMERIC(24,8) NOT NULL CHECK(low>0), close NUMERIC(24,8) NOT NULL CHECK(close>0),
 volume NUMERIC(30,8) NOT NULL CHECK(volume>=0), PRIMARY KEY(symbol,timeframe,candle_time), CHECK(high>=low)
);
CREATE TABLE IF NOT EXISTS team_decisions (
 decision_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), team_id TEXT NOT NULL REFERENCES teams(team_id),
 symbol TEXT NOT NULL, candle_time TIMESTAMPTZ NOT NULL, side TEXT NOT NULL CHECK(side IN ('BUY','SELL','HOLD')),
 confidence NUMERIC(8,6) NOT NULL CHECK(confidence BETWEEN 0 AND 1), reason TEXT NOT NULL,
 approved BOOLEAN NOT NULL, veto_reason TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(team_id,symbol,candle_time)
);
CREATE TABLE IF NOT EXISTS orders (
 order_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), idempotency_key TEXT NOT NULL UNIQUE,
 team_id TEXT NOT NULL REFERENCES teams(team_id), symbol TEXT NOT NULL,
 side TEXT NOT NULL CHECK(side IN ('BUY','SELL')), quantity NUMERIC(30,12) NOT NULL CHECK(quantity>0),
 order_type TEXT NOT NULL DEFAULT 'MARKET_SIMULATED',
 status TEXT NOT NULL CHECK(status IN ('PENDING','FILLED','REJECTED','CANCELLED')), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS fills (
 fill_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), order_id UUID NOT NULL REFERENCES orders(order_id),
 fill_price NUMERIC(24,8) NOT NULL CHECK(fill_price>0), quantity NUMERIC(30,12) NOT NULL CHECK(quantity>0),
 fee_amount NUMERIC(30,12) NOT NULL DEFAULT 0 CHECK(fee_amount>=0),
 slippage_amount NUMERIC(30,12) NOT NULL DEFAULT 0 CHECK(slippage_amount>=0), filled_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS positions (
 position_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), team_id TEXT NOT NULL REFERENCES teams(team_id),
 symbol TEXT NOT NULL, quantity NUMERIC(30,12) NOT NULL CHECK(quantity>0),
 average_entry_price NUMERIC(24,8) NOT NULL CHECK(average_entry_price>0), stop_price NUMERIC(24,8) NOT NULL CHECK(stop_price>0),
 entry_fees NUMERIC(30,12) NOT NULL DEFAULT 0, opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 closed_at TIMESTAMPTZ, status TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','CLOSED'))
);
CREATE TABLE IF NOT EXISTS portfolio_snapshots (
 snapshot_id BIGSERIAL PRIMARY KEY, team_id TEXT NOT NULL REFERENCES teams(team_id),
 snapshot_time TIMESTAMPTZ NOT NULL DEFAULT now(), cash NUMERIC(30,12) NOT NULL, equity NUMERIC(30,12) NOT NULL,
 realized_pnl NUMERIC(30,12) NOT NULL, unrealized_pnl NUMERIC(30,12) NOT NULL
);
CREATE TABLE IF NOT EXISTS target_ledger (
 ledger_id BIGSERIAL PRIMARY KEY, team_id TEXT NOT NULL REFERENCES teams(team_id), period_date DATE NOT NULL,
 start_equity NUMERIC(30,12) NOT NULL, target_rate NUMERIC(10,8) NOT NULL, target_profit NUMERIC(30,12) NOT NULL,
 net_pnl NUMERIC(30,12) NOT NULL, shortfall_added NUMERIC(30,12) NOT NULL,
 outstanding_shortfall NUMERIC(30,12) NOT NULL, completed BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(team_id,period_date)
);
CREATE TABLE IF NOT EXISTS risk_events (
 risk_event_id BIGSERIAL PRIMARY KEY, team_id TEXT NOT NULL REFERENCES teams(team_id),
 event_time TIMESTAMPTZ NOT NULL DEFAULT now(), severity TEXT NOT NULL, code TEXT NOT NULL, message TEXT NOT NULL,
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS audit_log (
 audit_id BIGSERIAL PRIMARY KEY, actor TEXT NOT NULL DEFAULT 'system', action TEXT NOT NULL,
 entity_type TEXT NOT NULL, entity_id TEXT, details JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_candles_symbol_time ON candles(symbol,candle_time DESC);
CREATE INDEX IF NOT EXISTS idx_orders_team_time ON orders(team_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_snapshots_team_time ON portfolio_snapshots(team_id,snapshot_time DESC);
CREATE INDEX IF NOT EXISTS idx_risk_events_team_time ON risk_events(team_id,event_time DESC);

from datetime import datetime, timezone
from decimal import Decimal
from typing import Literal
from pydantic import BaseModel, Field, field_validator, model_validator

class Candle(BaseModel):
    timestamp: datetime
    open: Decimal = Field(gt=0)
    high: Decimal = Field(gt=0)
    low: Decimal = Field(gt=0)
    close: Decimal = Field(gt=0)
    volume: Decimal = Field(ge=0)

    @field_validator("timestamp")
    @classmethod
    def normalize_timestamp(cls, v):
        return v.replace(tzinfo=timezone.utc) if v.tzinfo is None else v.astimezone(timezone.utc)

    @model_validator(mode="after")
    def valid_ohlc(self):
        if self.high < max(self.open, self.close, self.low):
            raise ValueError("high must be >= open, close, and low")
        if self.low > min(self.open, self.close, self.high):
            raise ValueError("low must be <= open, close, and high")
        return self

class CandleBatch(BaseModel):
    symbol: str
    timeframe: Literal["1h"]
    candles: list[Candle] = Field(min_length=1, max_length=5000)

    @field_validator("symbol")
    @classmethod
    def valid_symbol(cls, v):
        v = v.upper().replace("-", "/")
        if v not in {"BTC/USDT", "ETH/USDT"}:
            raise ValueError("Only BTC/USDT and ETH/USDT are enabled")
        return v

    @field_validator("candles")
    @classmethod
    def chronological_unique(cls, values):
        stamps = [c.timestamp for c in values]
        if stamps != sorted(stamps) or len(stamps) != len(set(stamps)):
            raise ValueError("candles must be chronological with unique timestamps")
        return values

class EvaluateRequest(BaseModel):
    symbol: str = "BTC/USDT"

    @field_validator("symbol")
    @classmethod
    def valid_symbol(cls, v):
        v = v.upper().replace("-", "/")
        if v not in {"BTC/USDT", "ETH/USDT"}:
            raise ValueError("Only BTC/USDT and ETH/USDT are enabled")
        return v

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .agents import AGENTS, TEAMS
from .config import settings
from .engine import PaperEngine
from .models import CandleBatch, EvaluateRequest

app = FastAPI(title="NEXUS Crypto AI Paper Trading API", version="0.1.0",
              description="Paper trading only. No live order placement. Daily target is aspirational.")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3000"],
                   allow_credentials=False, allow_methods=["GET","POST"], allow_headers=["*"])
engine = PaperEngine()

@app.get("/health")
def health():
    return {"status":"ok","mode":"paper","live_order_placement":False}

@app.get("/v1/config")
def get_config():
    return {"mode":"paper","starting_capital_ngn":str(settings.starting_capital_ngn),
            "team_count":settings.team_count,"agents_per_team":settings.agents_per_team,
            "agent_count":len(AGENTS),"allocation_per_team_ngn":str(settings.starting_capital_ngn/settings.team_count),
            "symbols":settings.symbol_list,"timeframe":settings.timeframe,
            "fee_rate_per_side":str(settings.fee_rate),"risk_per_trade":str(settings.risk_per_trade),
            "daily_loss_limit":str(settings.daily_loss_limit),"daily_target":str(settings.daily_target),
            "equity_based_sizing":True,"carry_forward_ledger":True,"live_order_placement":False}

@app.get("/v1/teams")
def get_teams():
    rows = {x["team_id"]:x for x in engine.portfolio()["teams"]}
    return [{**t,**rows[t["team_id"]]} for t in TEAMS]

@app.get("/v1/agents")
def get_agents():
    return [a.__dict__ for a in AGENTS]

@app.post("/v1/market/candles")
def submit_candles(batch: CandleBatch):
    try:
        return engine.add_candles(batch.symbol,batch.candles)
    except ValueError as exc:
        raise HTTPException(status_code=409,detail=str(exc))

@app.get("/v1/market/candles/{symbol:path}")
def get_candles(symbol: str):
    normalized = symbol.upper().replace("-", "/")
    candles = engine.candles.get(normalized)
    if candles is None:
        raise HTTPException(status_code=404,detail="No candles found")
    return [{"timestamp":c.timestamp.isoformat(),"open":str(c.open),"high":str(c.high),
             "low":str(c.low),"close":str(c.close),"volume":str(c.volume)} for c in candles]

@app.post("/v1/engine/evaluate")
def evaluate(request: EvaluateRequest):
    result = engine.evaluate(request.symbol)
    engine.close_positions_at_stops()
    return result

@app.get("/v1/portfolio")
def portfolio():
    return engine.portfolio()

@app.get("/v1/positions")
def positions():
    return engine.positions()

@app.get("/v1/orders")
def orders():
    return engine.orders[-500:]

@app.get("/v1/ledger")
def ledger():
    return engine.ledger()

@app.get("/v1/events")
def events():
    return engine.events[-200:]

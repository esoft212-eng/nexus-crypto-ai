from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Sequence
from .models import Candle

@dataclass(frozen=True)
class Signal:
    side: str
    confidence: Decimal
    reason: str
    stop_price: Decimal | None
    candle_timestamp: datetime

class Strategy(ABC):
    name: str
    @abstractmethod
    def evaluate(self, candles: Sequence[Candle]) -> Signal:
        pass

def sma(values: Sequence[Decimal], period: int):
    if len(values) < period:
        return None
    return sum(values[-period:]) / Decimal(period)

class TrendStrategy(Strategy):
    name = "trend"
    def evaluate(self, candles):
        last = candles[-1]
        closes = [c.close for c in candles]
        fast, slow = sma(closes, 10), sma(closes, 24)
        if fast is None or slow is None or len(candles) < 25:
            return Signal("HOLD", Decimal("0"), "Insufficient candles for trend rule", None, last.timestamp)
        if fast > slow and last.close > fast:
            return Signal("BUY", Decimal("0.60"), "10-SMA above 24-SMA and close above fast average", last.close * Decimal("0.98"), last.timestamp)
        if fast < slow:
            return Signal("HOLD", Decimal("0.20"), "Trend filter is not bullish", None, last.timestamp)
        return Signal("HOLD", Decimal("0.10"), "No qualifying trend entry", None, last.timestamp)

class BreakoutStrategy(Strategy):
    name = "breakout"
    def evaluate(self, candles):
        last = candles[-1]
        if len(candles) < 21:
            return Signal("HOLD", Decimal("0"), "Insufficient candles for breakout rule", None, last.timestamp)
        prior_high = max(c.high for c in candles[-21:-1])
        if last.close > prior_high and last.volume > 0:
            return Signal("BUY", Decimal("0.58"), "Close above prior 20-candle high", last.close * Decimal("0.98"), last.timestamp)
        return Signal("HOLD", Decimal("0.10"), "No confirmed breakout", None, last.timestamp)

class MeanReversionStrategy(Strategy):
    name = "mean_reversion"
    def evaluate(self, candles):
        last = candles[-1]
        mean = sma([c.close for c in candles], 20)
        if mean is None:
            return Signal("HOLD", Decimal("0"), "Insufficient candles for mean-reversion rule", None, last.timestamp)
        if last.close < mean * Decimal("0.97"):
            return Signal("BUY", Decimal("0.52"), "Close 3% below 20-candle SMA", last.close * Decimal("0.98"), last.timestamp)
        return Signal("HOLD", Decimal("0.10"), "No qualifying mean-reversion entry", None, last.timestamp)

STRATEGY_MAP = {
 "trend": TrendStrategy(), "breakout": BreakoutStrategy(), "mean_reversion": MeanReversionStrategy(),
 # These families are explicit baselines pending their own tested implementations.
 "price_action": TrendStrategy(), "moving_average": TrendStrategy(), "volatility": BreakoutStrategy(),
 "multi_timeframe": TrendStrategy(), "volume": BreakoutStrategy(), "adaptive": TrendStrategy(), "research": TrendStrategy(),
}

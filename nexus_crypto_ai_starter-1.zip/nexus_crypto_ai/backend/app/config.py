from decimal import Decimal
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "postgresql+psycopg://nexus:nexus_dev_only@localhost:5432/nexus"
    starting_capital_ngn: Decimal = Decimal("100000")
    team_count: int = 10
    agents_per_team: int = 10
    fee_rate: Decimal = Decimal("0.001")
    risk_per_trade: Decimal = Decimal("0.005")
    daily_loss_limit: Decimal = Decimal("0.02")
    daily_target: Decimal = Decimal("0.20")
    timeframe: str = "1h"
    symbols: str = "BTC/USDT,ETH/USDT"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def symbol_list(self):
        return [s.strip().upper() for s in self.symbols.split(",") if s.strip()]

settings = Settings()

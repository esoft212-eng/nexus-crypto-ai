from dataclasses import dataclass
from datetime import date
from decimal import Decimal

@dataclass
class TargetLedger:
    team_id: str
    target_rate: Decimal = Decimal("0.20")
    outstanding_shortfall: Decimal = Decimal("0")
    completed_periods: int = 0
    current_period_start_equity: Decimal = Decimal("10000")
    current_period_net_pnl: Decimal = Decimal("0")
    current_period_date: date | None = None

    def close_period(self, start_equity: Decimal, net_pnl: Decimal, period_date: date) -> dict:
        target_profit = start_equity * self.target_rate
        shortfall = max(Decimal("0"), target_profit - net_pnl)
        self.outstanding_shortfall += shortfall
        complete = net_pnl >= target_profit
        if complete:
            self.completed_periods += 1
            self.outstanding_shortfall = max(Decimal("0"), self.outstanding_shortfall - target_profit)
        self.current_period_start_equity = start_equity
        self.current_period_net_pnl = net_pnl
        self.current_period_date = period_date
        return {
            "team_id": self.team_id, "date": period_date.isoformat(),
            "start_equity": str(start_equity), "net_pnl": str(net_pnl),
            "target_profit": str(target_profit), "shortfall_added": str(shortfall),
            "outstanding_shortfall": str(self.outstanding_shortfall), "completed": complete,
            "note": "Accounting metric only; never force or enlarge trades to recover shortfall."
        }

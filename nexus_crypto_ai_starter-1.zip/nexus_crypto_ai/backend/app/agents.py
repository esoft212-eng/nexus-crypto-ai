from dataclasses import dataclass

TEAM_NAMES = [
    ("T01", "Trend Hunters", "trend"),
    ("T02", "Breakout Squad", "breakout"),
    ("T03", "Price Action", "price_action"),
    ("T04", "Mean Reversion", "mean_reversion"),
    ("T05", "Moving Average Lab", "moving_average"),
    ("T06", "Volatility Team", "volatility"),
    ("T07", "Multi-Timeframe", "multi_timeframe"),
    ("T08", "Volume Intelligence", "volume"),
    ("T09", "Regime Adaptive", "adaptive"),
    ("T10", "Research & Control", "research"),
]
ROLE_SETS = {
 "trend": ["trend_reader","momentum_reader","ema_reader","sma_reader","volume_reader","rsi_reader","macd_reader","entry_timing","risk_reviewer","signal_validator"],
 "breakout": ["range_detector","breakout_detector","volume_confirm","volatility_check","retest_check","entry_timing","stop_planner","exit_planner","risk_reviewer","signal_validator"],
 "price_action": ["candle_reader","swing_structure","support_resistance","rejection_reader","momentum_reader","volume_reader","entry_timing","exit_planner","risk_reviewer","signal_validator"],
 "mean_reversion": ["range_detector","rsi_reader","deviation_reader","volatility_check","momentum_filter","entry_timing","exit_planner","risk_reviewer","regime_filter","signal_validator"],
 "moving_average": ["ema_reader","sma_reader","cross_detector","trend_filter","volume_reader","timeframe_filter","entry_timing","exit_planner","risk_reviewer","signal_validator"],
 "volatility": ["atr_reader","volatility_regime","range_reader","breakout_detector","liquidity_check","position_sizer","stop_planner","exit_planner","risk_reviewer","signal_validator"],
 "multi_timeframe": ["fast_tf_reader","medium_tf_reader","slow_tf_reader","daily_bias_reader","structure_reader","momentum_reader","entry_timing","exit_planner","risk_reviewer","signal_validator"],
 "volume": ["relative_volume","volume_spike","spread_check","depth_check","momentum_reader","breakout_detector","entry_timing","exit_planner","risk_reviewer","signal_validator"],
 "adaptive": ["trend_regime","range_regime","volatility_regime","correlation_reader","momentum_reader","strategy_selector","entry_timing","exit_planner","risk_reviewer","signal_validator"],
 "research": ["backtest_reviewer","statistical_validator","fee_model_reviewer","slippage_reviewer","overfit_detector","data_quality","entry_reviewer","exit_reviewer","risk_reviewer","final_approver"],
}
@dataclass(frozen=True)
class AgentConfig:
    agent_id: str
    team_id: str
    team_name: str
    role: str
    strategy: str
    enabled: bool = True

def build_agents():
    result = []
    for tid, name, strategy in TEAM_NAMES:
        for n, role in enumerate(ROLE_SETS[strategy], 1):
            result.append(AgentConfig(f"{tid}-A{n:02d}", tid, name, role, strategy))
    assert len(result) == 100 and len({a.agent_id for a in result}) == 100
    return result

AGENTS = build_agents()
TEAMS = [{"team_id": tid, "name": name, "strategy": strategy, "agent_count": 10}
         for tid, name, strategy in TEAM_NAMES]

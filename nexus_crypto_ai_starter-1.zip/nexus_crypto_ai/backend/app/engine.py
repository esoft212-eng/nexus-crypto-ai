from dataclasses import dataclass, field
from datetime import datetime, timezone, date
from decimal import Decimal, ROUND_DOWN
from .agents import TEAMS
from .config import settings
from .models import Candle
from .strategies import STRATEGY_MAP
from .ledger import TargetLedger

D = Decimal

@dataclass
class Position:
    team_id: str
    symbol: str
    quantity: Decimal
    entry_price: Decimal
    stop_price: Decimal
    entry_fee: Decimal
    opened_at: datetime

@dataclass
class TeamPortfolio:
    team_id: str
    name: str
    strategy: str
    starting_equity: Decimal
    cash: Decimal
    realized_pnl: Decimal = D("0")
    positions: dict = field(default_factory=dict)
    day_start_equity: Decimal = D("10000")
    risk_date: date | None = None
    paused_date: date | None = None
    paused_reason: str | None = None
    ledger: TargetLedger | None = None

    def equity(self, prices):
        total = self.cash
        for symbol, pos in self.positions.items():
            total += pos.quantity * prices.get(symbol, pos.entry_price)
        return total

class PaperEngine:
    def __init__(self):
        allocation = settings.starting_capital_ngn / D(settings.team_count)
        self.teams = {}
        for item in TEAMS:
            tid = item["team_id"]
            self.teams[tid] = TeamPortfolio(
                tid, item["name"], item["strategy"], allocation, allocation,
                day_start_equity=allocation,
                ledger=TargetLedger(tid, current_period_start_equity=allocation)
            )
        self.candles = {}
        self.events = []
        self.last_prices = {}
        self.orders = []

    def _event(self, level, message, team_id=None):
        self.events.append({"timestamp": datetime.now(timezone.utc).isoformat(),
                            "level": level, "team_id": team_id, "message": message})
        self.events = self.events[-1000:]

    def add_candles(self, symbol, candles):
        existing = self.candles.get(symbol, [])
        if existing and candles[0].timestamp <= existing[-1].timestamp:
            raise ValueError("new candles must start after the most recent stored candle")
        self.candles[symbol] = (existing + candles)[-5000:]
        self.last_prices[symbol] = candles[-1].close
        return {"symbol": symbol, "stored": len(candles), "total": len(self.candles[symbol]),
                "latest_timestamp": candles[-1].timestamp.isoformat(), "latest_close": str(candles[-1].close)}

    def _risk_paused(self, team, today):
        if team.risk_date != today:
            team.risk_date = today
            team.day_start_equity = team.equity(self.last_prices)
            team.paused_date, team.paused_reason = None, None
        floor = team.day_start_equity * (D("1") - settings.daily_loss_limit)
        if team.equity(self.last_prices) <= floor:
            team.paused_date = today
            team.paused_reason = f"Daily loss threshold reached: equity <= {floor}"
            self._event("WARN", team.paused_reason, team.team_id)
        return team.paused_date == today

    def _quantity_for_risk(self, team, entry, stop):
        equity = team.equity(self.last_prices)
        risk_budget = equity * settings.risk_per_trade
        risk_per_unit = abs(entry - stop)
        if risk_per_unit <= 0:
            return D("0")
        qty_by_risk = (risk_budget / risk_per_unit).quantize(D("0.00000001"), rounding=ROUND_DOWN)
        affordable = (team.cash / (entry * (D("1") + settings.fee_rate))).quantize(D("0.00000001"), rounding=ROUND_DOWN)
        return max(D("0"), min(qty_by_risk, affordable))

    def _buy(self, team, symbol, price, stop, timestamp):
        if symbol in team.positions:
            return {"status": "rejected", "reason": "position already open", "team_id": team.team_id}
        if stop >= price:
            return {"status": "rejected", "reason": "long stop must be below entry", "team_id": team.team_id}
        qty = self._quantity_for_risk(team, price, stop)
        if qty <= 0:
            return {"status": "rejected", "reason": "quantity is zero or unaffordable", "team_id": team.team_id}
        gross, fee = qty * price, qty * price * settings.fee_rate
        if gross + fee > team.cash:
            return {"status": "rejected", "reason": "insufficient cash after fees", "team_id": team.team_id}
        team.cash -= gross + fee
        team.positions[symbol] = Position(team.team_id, symbol, qty, price, stop, fee, timestamp)
        order = {"status": "filled", "side": "BUY", "team_id": team.team_id, "symbol": symbol,
                 "quantity": str(qty), "price": str(price), "fee": str(fee), "timestamp": timestamp.isoformat()}
        self.orders.append(order)
        self._event("INFO", f"Paper BUY {symbol} qty={qty} price={price} fee={fee}", team.team_id)
        return order

    def evaluate(self, symbol):
        candles = self.candles.get(symbol, [])
        if not candles:
            return {"symbol": symbol, "evaluated": 0, "results": [], "message": "No candles submitted"}
        last = candles[-1]
        self.last_prices[symbol] = last.close
        results = []
        for team in self.teams.values():
            if self._risk_paused(team, last.timestamp.date()):
                results.append({"team_id": team.team_id, "status": "paused", "reason": team.paused_reason})
                continue
            signal = STRATEGY_MAP[team.strategy].evaluate(candles)
            if signal.side != "BUY":
                results.append({"team_id": team.team_id, "status": "no_trade", "side": signal.side,
                                "confidence": str(signal.confidence), "reason": signal.reason})
                continue
            if signal.confidence < D("0.50") or signal.stop_price is None:
                results.append({"team_id": team.team_id, "status": "rejected", "reason": "signal confidence or stop requirement failed"})
                continue
            results.append({**self._buy(team, symbol, last.close, signal.stop_price, last.timestamp),
                            "reason": signal.reason, "confidence": str(signal.confidence)})
        return {"symbol": symbol, "evaluated": len(results), "candle_timestamp": last.timestamp.isoformat(), "results": results}

    def close_positions_at_stops(self):
        closed = []
        for team in self.teams.values():
            for symbol, pos in list(team.positions.items()):
                candles = self.candles.get(symbol, [])
                if not candles:
                    continue
                candle = candles[-1]
                if candle.low <= pos.stop_price:
                    exit_price = min(pos.stop_price, candle.open)
                    gross = pos.quantity * exit_price
                    fee = gross * settings.fee_rate
                    team.cash += gross - fee
                    pnl = (exit_price - pos.entry_price) * pos.quantity - pos.entry_fee - fee
                    team.realized_pnl += pnl
                    del team.positions[symbol]
                    row = {"status": "filled", "side": "SELL", "team_id": team.team_id, "symbol": symbol,
                           "quantity": str(pos.quantity), "price": str(exit_price), "fee": str(fee),
                           "realized_pnl": str(pnl), "reason": "stop_loss", "timestamp": candle.timestamp.isoformat()}
                    self.orders.append(row); closed.append(row)
                    self._event("WARN", f"Stop executed for {symbol}; realized P&L={pnl}", team.team_id)
        return closed

    def portfolio(self):
        rows = []
        for t in self.teams.values():
            equity = t.equity(self.last_prices)
            rows.append({"team_id": t.team_id, "name": t.name, "strategy": t.strategy,
                         "starting_equity": str(t.starting_equity), "cash": str(t.cash),
                         "equity": str(equity), "realized_pnl": str(t.realized_pnl),
                         "unrealized_pnl": str(equity - t.starting_equity - t.realized_pnl),
                         "positions": len(t.positions), "paused": t.paused_date is not None,
                         "paused_reason": t.paused_reason})
        total = sum((D(r["equity"]) for r in rows), D("0"))
        return {"currency": "NGN", "starting_capital": str(settings.starting_capital_ngn),
                "equity": str(total), "net_pnl": str(total-settings.starting_capital_ngn), "teams": rows}

    def positions(self):
        rows = []
        for t in self.teams.values():
            for p in t.positions.values():
                mark = self.last_prices.get(p.symbol, p.entry_price)
                rows.append({"team_id": p.team_id, "symbol": p.symbol, "quantity": str(p.quantity),
                             "entry_price": str(p.entry_price), "mark_price": str(mark),
                             "stop_price": str(p.stop_price),
                             "unrealized_pnl_before_exit_fee": str((mark-p.entry_price)*p.quantity-p.entry_fee),
                             "entry_fee": str(p.entry_fee), "opened_at": p.opened_at.isoformat()})
        return rows

    def ledger(self):
        return [{"team_id": t.team_id, "target_rate": str(t.ledger.target_rate),
                 "outstanding_shortfall": str(t.ledger.outstanding_shortfall),
                 "completed_periods": t.ledger.completed_periods,
                 "current_period_start_equity": str(t.ledger.current_period_start_equity),
                 "note": "Target shortfall is accounting only and never causes forced trades."}
                for t in self.teams.values()]

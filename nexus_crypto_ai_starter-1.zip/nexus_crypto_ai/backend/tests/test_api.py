from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

def test_health_paper_only():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["live_order_placement"] is False

def test_config():
    data = client.get("/v1/config").json()
    assert data["team_count"] == 10
    assert data["agent_count"] == 100
    assert data["live_order_placement"] is False

from datetime import datetime, timezone
from decimal import Decimal as D
from app.engine import PaperEngine
from app.models import Candle

def candle(i, close):
    ts = datetime(2026,1,1,i,tzinfo=timezone.utc)
    p = D(str(close))
    return Candle(timestamp=ts,open=p,high=p*D("1.01"),low=p*D("0.99"),close=p,volume=D("100"))

def test_initial_allocation():
    e = PaperEngine()
    p = e.portfolio()
    assert D(p["starting_capital"]) == D("100000")
    assert len(p["teams"]) == 10
    assert all(D(t["starting_equity"]) == D("10000") for t in p["teams"])

def test_no_candles_no_trades():
    e = PaperEngine()
    r = e.evaluate("BTC/USDT")
    assert r["evaluated"] == 0 and r["results"] == []

def test_candle_evaluation():
    e = PaperEngine()
    e.add_candles("BTC/USDT",[candle(i,100+i) for i in range(30)])
    r = e.evaluate("BTC/USDT")
    assert r["evaluated"] == 10

from app.agents import AGENTS, TEAMS

def test_exactly_100_agents_and_10_teams():
    assert len(AGENTS) == 100
    assert len({a.agent_id for a in AGENTS}) == 100
    assert len(TEAMS) == 10
    assert all(sum(a.team_id == t["team_id"] for a in AGENTS) == 10 for t in TEAMS)

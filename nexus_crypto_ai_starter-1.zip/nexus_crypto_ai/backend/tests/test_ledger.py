from datetime import date
from decimal import Decimal as D
from app.ledger import TargetLedger

def test_shortfall_is_accounting_only():
    ledger = TargetLedger("T01", target_rate=D("0.20"), current_period_start_equity=D("10000"))
    row = ledger.close_period(D("10000"), D("800"), date(2026,1,1))
    assert row["completed"] is False
    assert D(row["shortfall_added"]) == D("1200")
    assert "never force" in row["note"]

def test_target_completion():
    ledger = TargetLedger("T01", target_rate=D("0.20"), current_period_start_equity=D("10000"))
    row = ledger.close_period(D("10000"), D("2000"), date(2026,1,1))
    assert row["completed"] is True
    assert ledger.completed_periods == 1
